package cc.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;

/**
 * ClientCore (Fabric 1.20.1, yalnizca istemci):
 *  - Akici fade-in'li HUD: FPS, %1 low, kare suresi, ping, hiz + kare suresi grafigi
 *  - Yay-sonumleyici ile yumusak zoom (hafif overshoot)
 * Tuslar: C = zoom (basili tut), H = HUD ac/kapa
 */
public class ClientCoreMod implements ClientModInitializer {

    // ------------------------------------------------------------ Yay (analitik)
    static final class Spring {
        float pos, vel;
        void step(float target, float dt, float omega, float zeta) {
            float pp, pv, vp, vv;
            final float e = 1e-4f;
            if (zeta > 1f + e) {
                float za = -omega * zeta, zb = omega * (float) Math.sqrt(zeta * zeta - 1f);
                float z1 = za - zb, z2 = za + zb;
                float e1 = (float) Math.exp(z1 * dt), e2 = (float) Math.exp(z2 * dt);
                float inv = 1f / (2f * zb), e1o = e1 * inv, e2o = e2 * inv;
                float z1e1 = z1 * e1o, z2e2 = z2 * e2o;
                pp = e1o * z2 - z2e2 + e2; pv = -e1o + e2o;
                vp = (z1e1 - z2e2 + e2) * z2; vv = -z1e1 + z2e2;
            } else if (zeta < 1f - e) {
                float oz = omega * zeta, al = omega * (float) Math.sqrt(1f - zeta * zeta);
                float ex = (float) Math.exp(-oz * dt), c = (float) Math.cos(al * dt), s = (float) Math.sin(al * dt);
                float inv = 1f / al, exs = ex * s, exc = ex * c, ozs = ex * oz * s * inv;
                pp = exc + ozs; pv = exs * inv; vp = -exs * al - oz * ozs; vv = exc - ozs;
            } else {
                float ex = (float) Math.exp(-omega * dt), t = dt * ex, tf = t * omega;
                pp = tf + ex; pv = t; vp = -omega * tf; vv = -tf + ex;
            }
            float p0 = pos - target, v0 = vel;
            pos = p0 * pp + v0 * pv + target;
            vel = p0 * vp + v0 * vv;
        }
    }

    // ------------------------------------------------------------------ Durum
    private static KeyBinding zoomKey, hudKey;
    private static boolean zooming, hudVisible = true;

    private static final Spring fovSpring = new Spring();
    private static long lastFovNs;

    private static final int N = 120;
    private static final float[] frameMs = new float[N];
    private static final float[] scratch = new float[N];
    private static int ringIdx, ringCount;
    private static long lastFrameNs;
    private static float hudAlpha;

    @Override
    public void onInitializeClient() {
        fovSpring.pos = 1f;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientcore.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.clientcore"));
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientcore.hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.clientcore"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            zooming = zoomKey.isPressed();
            while (hudKey.wasPressed()) hudVisible = !hudVisible;
        });
        HudRenderCallback.EVENT.register(ClientCoreMod::renderHud);
    }

    /** Mixin her getFov cagrisinda okur; zaman tabanli oldugu icin kac kez cagrilirsa cagrilsin dogru. */
    public static float fovMultiplier() {
        long now = System.nanoTime();
        float dt = lastFovNs == 0 ? 0f : Math.min((now - lastFovNs) / 1e9f, 0.1f);
        lastFovNs = now;
        if (dt > 0f) fovSpring.step(zooming ? 0.25f : 1f, dt, 16f, 0.7f); // zeta<1: hafif overshoot
        return Math.max(0.1f, Math.min(1.2f, fovSpring.pos));
    }

    // -------------------------------------------------------------------- HUD
    private static int argb(int a, int r, int g, int b) { return (a << 24) | (r << 16) | (g << 8) | b; }

    private static void renderHud(DrawContext ctx, float tickDelta) {
        long now = System.nanoTime();
        float dtMs = lastFrameNs == 0 ? 16.7f : (now - lastFrameNs) / 1e6f;
        lastFrameNs = now;
        frameMs[ringIdx] = dtMs;
        ringIdx = (ringIdx + 1) % N;
        ringCount = Math.min(ringCount + 1, N);

        // Fade-in / fade-out (kare hizindan bagimsiz ussel yumusatma)
        float target = hudVisible ? 1f : 0f;
        hudAlpha += (target - hudAlpha) * (1f - (float) Math.exp(-9f * dtMs / 1000f));
        if (hudAlpha < 0.03f) return; // (alfa<4 metin opak cizilir; bu yuzden atliyoruz)

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float sum = 0f;
        for (int i = 0; i < ringCount; i++) sum += frameMs[i];
        float avg = sum / ringCount;
        int fps = avg > 0f ? Math.round(1000f / avg) : 0;

        System.arraycopy(frameMs, 0, scratch, 0, ringCount);
        Arrays.sort(scratch, 0, ringCount);
        int k = Math.max(1, ringCount / 100);
        float worst = 0f;
        for (int i = 0; i < k; i++) worst += scratch[ringCount - 1 - i];
        int low = worst > 0f ? Math.round(1000f * k / worst) : 0;

        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        Vec3d v = mc.player.getVelocity();
        float speed = (float) Math.sqrt(v.x * v.x + v.z * v.z) * 20f;

        int a = (int) (hudAlpha * 255f);
        int x = 6, y = 6, w = 124, h = 72;
        ctx.fill(x, y, x + w, y + h, argb((int) (hudAlpha * 140f), 10, 12, 18));
        ctx.fill(x, y, x + 2, y + h, argb(a, 90, 200, 255));

        int text = argb(a, 235, 240, 245);
        int dim = argb(a, 150, 160, 175);
        ctx.drawTextWithShadow(mc.textRenderer, "FPS " + fps + "  (1% " + low + ")", x + 6, y + 4, text);
        ctx.drawTextWithShadow(mc.textRenderer, String.format("Kare %.1f ms", avg), x + 6, y + 15, text);
        ctx.drawTextWithShadow(mc.textRenderer, "Ping " + ping + " ms", x + 6, y + 26, dim);
        ctx.drawTextWithShadow(mc.textRenderer, String.format("Hiz %.1f b/s", speed), x + 6, y + 37, dim);

        // Kare suresi grafigi: son 60 kare, yesil <=16.7ms, sari <=33ms, kirmizi ustu
        int gx = x + 6, gBase = y + h - 4, bars = 56;
        for (int i = 0; i < bars && i < ringCount; i++) {
            float ms = frameMs[(ringIdx - bars + i + N * 2) % N];
            int bh = Math.max(1, Math.round(Math.min(ms, 33.3f) / 33.3f * 18f));
            int col = ms <= 16.7f ? argb(a, 90, 220, 120) : ms <= 33.3f ? argb(a, 240, 200, 80) : argb(a, 240, 90, 90);
            ctx.fill(gx + i * 2, gBase - bh, gx + i * 2 + 1, gBase, col);
        }
    }
}
